import shutil, os, datetime
from datetime import timedelta
from datetime import datetime

currentTime = datetime.now()
timestamp = currentTime + timedelta(hours=-24)

folderA = "C:\\Users\\cland\\Desktop\\Customers\\"
folderB = "C:\\Users\\cland\\Desktop\\CustomerDailyUpdates\\"

source = folderA
destination = folderB
    
sourceFiles = os.listdir(source)

for x in sourceFiles:
    fileModifyTime = datetime.fromtimestamp(os.path.getmtime(source+x))
    compareTime = (currentTime - fileModifyTime)
    if compareTime < timedelta(hours=24):
       shutil.copy(source +'/'+x, destination)

print os.listdir(destination)
