import shutil
import os

folderA = "C:\\Users\\cland\\Desktop\\FolderA\\"
folderB = "C:\\Users\\cland\\Desktop\\FolderB\\"

source = folderA
destination = folderB

for x in os.listdir(source):
    shutil.move(source +'/'+x, destination)

print os.listdir(destination)
