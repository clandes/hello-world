import shutil
shutil.move('C:\\Users\\Cheryl\\Desktop\\FolderA\\bears.txt', 'C:\\Users\\Cheryl\\FolderB\\')
shutil.move('C:\\Users\\Cheryl\\Desktop\\FolderA\\frogs.txt', 'C:\\Users\\Cheryl\\FolderB\\')
shutil.move('C:\\Users\\Cheryl\\Desktop\\FolderA\\dogs.txt', 'C:\\Users\\Cheryl\\FolderB\\')
shutil.move('C:\\Users\\Cheryl\\Desktop\\FolderA\\cats.txt', 'C:\\Users\\Cheryl\\FolderB\\')

